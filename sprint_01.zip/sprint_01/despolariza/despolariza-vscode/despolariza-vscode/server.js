// server.js — usa json-server oficial + serve o index.html estático
// Instalação: npm install
// Uso:        node server.js

const jsonServer = require("json-server");
const path       = require("path");

const app         = jsonServer.create();
const router      = jsonServer.router(path.join(__dirname, "db.json"));
const middlewares = jsonServer.defaults({
  static: __dirname,   // serve index.html na raiz
});

const PORT = 3000;

// Middlewares padrão do json-server (logger, cors, body-parser, etc.)
app.use(middlewares);

// Adiciona campo "data" automaticamente em todo POST
app.use(jsonServer.bodyParser);
app.use((req, res, next) => {
  if (req.method === "POST") {
    req.body.data = new Date().toISOString();
  }
  next();
});

// Rotas da API (ex: /avaliacoes)
app.use(router);

app.listen(PORT, () => {
  console.log(`\n🚀 json-server rodando em http://localhost:${PORT}`);
  console.log(`📄 Página:  http://localhost:${PORT}/index.html`);
  console.log(`🗃️  API:     http://localhost:${PORT}/avaliacoes`);
  console.log("\nPressione Ctrl+C para parar.\n");
});
