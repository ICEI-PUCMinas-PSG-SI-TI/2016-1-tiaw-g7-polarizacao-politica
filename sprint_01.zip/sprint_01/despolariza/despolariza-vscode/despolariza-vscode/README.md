# Despolariza! 🗳️

Projeto web com Bootstrap 5, JavaScript e json-server.

---

## Abrir no VS Code

Dê duplo clique em **`despolariza.code-workspace`**
ou pelo terminal:

```bash
code despolariza.code-workspace
```

---

## Rodar o projeto

### 1. Instalar dependências (só na primeira vez)
```bash
npm install
```

### 2. Iniciar o servidor
```bash
npm start
```

Acesse: **http://localhost:3000**

> Ou pressione **F5** dentro do VS Code para iniciar pelo debugger.

---

## Estrutura

```
despolariza/
├── despolariza.code-workspace  ← abrir no VS Code
├── index.html                  ← página principal
├── server.js                   ← servidor (json-server)
├── db.json                     ← banco de dados das avaliações
└── package.json
```

---

## Extensões recomendadas (VS Code instala automaticamente)

| Extensão | Função |
|---|---|
| Live Server | Abre o HTML com reload automático |
| Prettier | Formata o código |
| Auto Rename Tag | Renomeia tags HTML em par |
| ESLint | Erros de JavaScript em tempo real |
| Path Intellisense | Autocomplete de caminhos |
